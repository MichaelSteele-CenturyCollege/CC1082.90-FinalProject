
public class PassengerSeat {
	
	private boolean isVacant;
	
	
	public boolean isVacant() {
		return isVacant;
	}

	public void setVacant(boolean isVacant) {
		this.isVacant = isVacant;
	}

	public PassengerSeat() {
		this.isVacant = true;
		//count++;
	}
	
	public void occupySeat() {
		this.isVacant = false;
	}
	
	public void freeSeat() {
		this.isVacant = true;
	}
	
	public String returnSeatLetter(String letter){
		if (!this.isVacant)
			letter = "X";
		return letter;
	}
	
	public String toString(){
		return "Vacancy: " + this.isVacant();
	}

}
