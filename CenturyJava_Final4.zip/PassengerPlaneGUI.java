// COMPLETE! Just needs commenting and signing. 
// This version created by Michael Steele, 5/1/17 4:10PM EDITED BY DAN BELAIR 5/1/17
// If you spot any errors at all while testing this code, make any necessary fixes and upload to GitHub
// Final Project group: Michael Steele, Daniel Belair, Marekegn Tamenut
// Century College CSCI 1082.90 Object-Oriented Programming, Zakaria Baani.

import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;


public class PassengerPlaneGUI extends JFrame implements ActionListener {
	
	public static final int W = 600;
	public static final int H = 450;
	private final int ROWS = 7;
	private final int COLS = 4;
	private int count = 0;
	private PassengerSeat[][] Seats = new PassengerSeat[ROWS][COLS];
	
	private JPanel topPanel = new JPanel(new BorderLayout());
	private JPanel middlePanel = new JPanel(new BorderLayout());
	private JPanel bottomPanel = new JPanel(new BorderLayout());
	private JPanel displayPanel = new JPanel (new BorderLayout());
	private JPanel inputPanel = new JPanel(new FlowLayout());
	private JPanel actionPanel = new JPanel(new FlowLayout());
	private JPanel outputPanel = new JPanel (new BorderLayout());
	
	private JLabel inputLbl = new JLabel("Seat Designation: ");
	
	private JLabel rowLbl = new JLabel("Seat Row: ");
	private JLabel colLbl = new JLabel("Seat Letter: ");
	
	String[] rowChoices = {"1","2","3","5","6","7"};
	String[] colChoices = {"A","B","C","D"};
	final JComboBox<String> rowInput = new JComboBox<String>(rowChoices);
	final JComboBox<String> colInput = new JComboBox<String>(colChoices);
	
	//JTextPane is like JTextArea, but with the added functionality of being able to align text
	private JTextPane displayPane = new JTextPane();
	
	private JTextArea outputField = new JTextArea();
	
	// These two lines of code are used to center-align the displayPane
	private StyledDocument doc = displayPane.getStyledDocument();
	private SimpleAttributeSet center = new SimpleAttributeSet();
	
	private JButton bookBtn = new JButton("Book Seat");
	private JButton unbookBtn = new JButton("Unbook Seat");
	private JButton finishBtn = new JButton("Exit");
	
	public PassengerPlaneGUI(String title) {
		super(title);
		this.setSize(W, H);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(3, 1));
		buildPanels();
		addPanelsToFrame();
		addActionListeners();
		populatePlane();
		displayPane.setEditable(false);
		outputField.setEditable(false);
		
		// These three lines center the text in the displayPane
		StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
		doc.setParagraphAttributes(0, doc.getLength(), center, false);
		displayPane.setText(displaySeats());
	}
	
	
	private void addActionListeners() {
		bookBtn.addActionListener(this);
		unbookBtn.addActionListener(this);
		finishBtn.addActionListener(this);
		rowInput.addActionListener(this);
		colInput.addActionListener(this);
	}


	private void buildPanels() {
		displayPanel.add(displayPane);
		
		//inputPanel.add(inputLbl);   REMOVED WHEN J COMBOBOX ADDED
		//inputPanel.add(inputField);   REMOVED WHEN J COMBOBOX ADDED
		
		inputPanel.add(rowLbl);
		inputPanel.add(rowInput);
		inputPanel.add(colLbl);
		inputPanel.add(colInput);
		
		actionPanel.add(bookBtn);
		actionPanel.add(unbookBtn);
		actionPanel.add(finishBtn);
		
		outputPanel.add(outputField);
		JScrollPane scroll = new JScrollPane(outputField);
		outputPanel.add(scroll);
		
		topPanel.add(displayPanel, BorderLayout.CENTER);
		
		middlePanel.add(inputPanel, BorderLayout.CENTER);
		middlePanel.add(actionPanel, BorderLayout.SOUTH);
		bottomPanel.add(outputPanel, BorderLayout.CENTER);
		
	}
	
	private void addPanelsToFrame() {
		this.add(topPanel);
		this.add(middlePanel);
		this.add(bottomPanel);
	}

//increments counts to track when seats are full
	public void plusCount(){
		this.count++;
	}
	
	public void minusCount(){
		this.count--;
	}
	
	public PassengerSeat getSeat(int row, int col) {
		return this.Seats[row - 1][col - 1];
	}
	
	//populates and array for the seats of the plane
	public void populatePlane(){
		for (int outCount = 0; outCount < ROWS; outCount++){
			for (int inCount = 0; inCount < COLS; inCount++){
				PassengerSeat tempSeat = new PassengerSeat();
				this.Seats[outCount][inCount] = tempSeat;
			}
		}
		
	}
	
	public void addSeat(int row, int col){
		PassengerSeat newSeat = new PassengerSeat();
		newSeat.occupySeat();
		Seats[row - 1][col - 1] = newSeat;
	}
	
	public void freeSeat(int row, int col){
		PassengerSeat replaceSeat = new PassengerSeat();
		replaceSeat.freeSeat();
		Seats[row - 1][col - 1] = replaceSeat;
	}
	
	// The displaySeats() method has been changed to return a String instead of printing the output to work in tandem with the JTextPane
	public String displaySeats(){
		String identifier = "";
		for (int outCount = 0; outCount < ROWS; outCount++){
			identifier = identifier.concat((outCount + 1) + "\t\t");
			for (int inCount = 0; inCount < COLS; inCount++){
				switch (inCount) {
				case 0: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("A"));
						break;
				case 1: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("B"));
						break;
				case 2: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("C"));
						break;
				case 3: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("D"));
						break;
				}
				identifier = identifier.concat("\t\t");
			}
			identifier = identifier.concat("\n");
		}
		identifier = identifier.concat("\n");
		return identifier;
	}
	
	//this method should no longer be needed with the Jcombobox menu
	public boolean isCorrectFormat(String num, String let) {
		boolean flag = true;
		int aNum;
		String str;
		try{
			aNum = Integer.parseInt(num);
		} catch(Exception e) {
			flag = false;
		}
		try {
			str = let;
			aNum = Integer.parseInt(str);
			flag = false;
		} catch(Exception e) {
			// This try-catch statement only exists to ensure that the string is a letter and not a number
		}
		return flag;
	}
	
	//Checks the validity of inputs, also needed less with JcomboBox limiting inputs.
	public boolean isValidInput(String inputString, String operation){
		boolean flag = true;
		String[] splitInput = new String[2];
		int userRow, userCol = 0;
		String userLetterString = "";
		splitInput = inputString.split("");
		
			if (operation.equals("book") && this.count >= (this.ROWS * this.COLS)) {
				outputField.append("You have booked all available seats!\n");
				flag = false;
				return flag;
			}
		
			if (inputString == null || inputString.length() != 2 || !isCorrectFormat(splitInput[0], splitInput[1])) {
				outputField.append("Invalid input! Enter the seat in the format [NUMBER, LETTER].\n");
				outputField.append("Make sure your row number and column letter exist in the seating arrangement.\n");
				flag = false;
				return flag;
			}
			
	//the following code is the Heart of the program. Holdover from the text input version. This code is still used with JcomboBox.
			try {
				userRow = Integer.parseInt(splitInput[0]);
				userLetterString = splitInput[1].toUpperCase();
				if (userRow < 1 || userRow > 7){
					outputField.append("Please enter a valid row number.\n");
					flag = false;
					return flag;
				}
	//converts the 			
				switch (userLetterString) {
				case "A": userCol = 1;
						break;
				case "B": userCol = 2;
						break;
				case "C": userCol = 3;
						break;
				case "D": userCol = 4;
						break;
				default: outputField.append("Please enter a valid seat letter.\n");
						flag = false;
						return flag;
				}
				
				if (operation.equals("book")){
					if (getSeat(userRow, userCol).getisVacant()) {
						addSeat(userRow, userCol);
						displaySeats();
						plusCount();	
					}
					else {
						outputField.append("That seat has already been filled! Please choose another seat.\n");
						flag = false;
					}
				} else if (operation.equals("unbook")) {
					if (!getSeat(userRow, userCol).getisVacant()) {
						freeSeat(userRow, userCol);
						displaySeats();
						minusCount();	
					}
					else {
						outputField.append("That seat has not yet been booked!\n");
						flag = false;
					}
				}
				
			} catch (Exception e) {
				flag = false;
				outputField.append("Invalid input! Please enter the seat designation as number first, then letter. Do not use spaces.\n");
			}
		
		return flag;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		String callingBtn = event.getActionCommand();
		
		
		if (callingBtn.equals("Book Seat")) {
			String input = rowInput.getSelectedItem().toString() + colInput.getSelectedItem().toString();;
			if (isValidInput(input, "book") == true) {
				outputField.append("Seat booked successfully!\n");
				displayPane.setText(displaySeats());
			}
		} else if (callingBtn.equals("Unbook Seat")) {
			String input = rowInput.getSelectedItem().toString() + colInput.getSelectedItem().toString();;
			if (isValidInput(input, "unbook") == true) {
				outputField.append("Seat unbooked successfully!\n GET OFF THE PLANE !");
				displayPane.setText(displaySeats());
			}
		} else if (callingBtn.equals("Exit")) {
			System.exit(0);
		}
		
		
	}
	
	public static void main(String[] args) {
		PassengerPlaneGUI plane = new PassengerPlaneGUI("Reservation System");
		plane.setVisible(true);
	}
}
