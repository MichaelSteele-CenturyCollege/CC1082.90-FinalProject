// This class is responsible for managing each individual Seat (and representing those Seats)
public class PassengerSeat {
	// Flag to signal whether Seat is vacant or not
	private boolean isVacant;
	
	// Getters and setters
	public boolean getisVacant() {
		return isVacant;
	}

	public void setVacant(boolean isVacant) {
		this.isVacant = isVacant;
	}
	// No-arg constructor
	public PassengerSeat() {
		this.isVacant = true;
		//count++;
	}
	// Occupy the seat
	public void occupySeat() {
		this.isVacant = false;
	}
	// Free the seat
	public void freeSeat() {
		this.isVacant = true;
	}
	// Returns argument if vacant, returns 'X' if not
	public String returnSeatLetter(String letter){
		if (!this.isVacant)
			letter = "X";
		return letter;
	}
	// toString() method
	@Override
	public String toString(){
		return "Vacancy: " + this.getisVacant();
	}

}
