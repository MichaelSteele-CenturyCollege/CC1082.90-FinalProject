// Century College CSCI 1082.90 Object-Oriented Programming, Zakaria Baani.
// Final Project group: Michael Steele, Daniel Belair, Marekegn Tamenut
//
// This program opens a GUI interface through which the user may book airline seats. The interface is user-friendly and foolproof.
// The program offers a way to unbook seats and will constantly update the seating arrangement after each successful book and unbook.
// When the user is finished, they may press Exit to terminate the program.

// Import from all necessary packages
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;


public class PassengerPlaneGUI extends JFrame implements ActionListener { // Extends JFrame and implements ActionListener to enable GUI functions
	
	// Set size variables to be used with JFrame
	public static final int W = 600;
	public static final int H = 450;
	
	// Set size variables for the seating (populatePlane() function and JComboBox must also be extended accordingly if any values change)
	private final int ROWS = 7;
	private final int COLS = 4;
	// Used to keep track of seating
	private int count = 0;
	// Seats array acts as the 7 by 4 grid for the seating arrangement
	private PassengerSeat[][] Seats = new PassengerSeat[ROWS][COLS]; 
	
	// Create GUI elements
	private JPanel topPanel = new JPanel(new BorderLayout());
	private JPanel middlePanel = new JPanel(new BorderLayout());
	private JPanel bottomPanel = new JPanel(new BorderLayout());
	private JPanel displayPanel = new JPanel (new BorderLayout());
	private JPanel inputPanel = new JPanel(new FlowLayout());
	private JPanel actionPanel = new JPanel(new FlowLayout());
	private JPanel outputPanel = new JPanel (new BorderLayout());
	
	private JLabel inputLbl = new JLabel("Seat Designation: ");
	
	private JLabel rowLbl = new JLabel("Seat Row: ");
	private JLabel colLbl = new JLabel("Seat Letter: ");
	
	String[] rowChoices = {"1","2","3","5","6","7"};
	String[] colChoices = {"A","B","C","D"};
	final JComboBox<String> rowInput = new JComboBox<String>(rowChoices);
	final JComboBox<String> colInput = new JComboBox<String>(colChoices);
	
	//JTextPane is like JTextArea, but with the added functionality of being able to align text
	private JTextPane displayPane = new JTextPane();
	
	private JTextArea outputField = new JTextArea();
	
	// These two lines of code are used to center-align the displayPane
	private StyledDocument doc = displayPane.getStyledDocument();
	private SimpleAttributeSet center = new SimpleAttributeSet();
	
	// Create and label JButtons
	private JButton bookBtn = new JButton("Book Seat");
	private JButton unbookBtn = new JButton("Unbook Seat");
	private JButton finishBtn = new JButton("Exit");
	
	// Initialize all necessary values and call foundation methods with constructor
	public PassengerPlaneGUI(String title) {
		super(title);
		this.setSize(W, H);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(3, 1));
		// Call these functions
		buildPanels();
		addPanelsToFrame();
		addActionListeners();
		populatePlane();
		// Set the text area and pane to be non-editable
		displayPane.setEditable(false);
		outputField.setEditable(false);
		
		// These three lines center the text in the displayPane
		StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
		doc.setParagraphAttributes(0, doc.getLength(), center, false);
		displayPane.setText(displaySeats());
	}
	
	// Adds ActionListeners for the buttons
	private void addActionListeners() {
		bookBtn.addActionListener(this);
		unbookBtn.addActionListener(this);
		finishBtn.addActionListener(this);
		rowInput.addActionListener(this);
		colInput.addActionListener(this);
	}

	// Builds the GUI panels
	private void buildPanels() {
		displayPanel.add(displayPane);
		
		inputPanel.add(rowLbl);
		inputPanel.add(rowInput);
		inputPanel.add(colLbl);
		inputPanel.add(colInput);
		
		actionPanel.add(bookBtn);
		actionPanel.add(unbookBtn);
		actionPanel.add(finishBtn);
		
		outputPanel.add(outputField);
		JScrollPane scroll = new JScrollPane(outputField);
		outputPanel.add(scroll);
		
		topPanel.add(displayPanel, BorderLayout.CENTER);
		
		middlePanel.add(inputPanel, BorderLayout.CENTER);
		middlePanel.add(actionPanel, BorderLayout.SOUTH);
		bottomPanel.add(outputPanel, BorderLayout.CENTER);
		
	}
	
	// Adds panels to JFrame
	private void addPanelsToFrame() {
		this.add(topPanel);
		this.add(middlePanel);
		this.add(bottomPanel);
	}

	// Increments seat count to regulate seating availability
	public void plusCount(){
		this.count++;
	}
	
	// Decrements seat count to regulate seating availability
	public void minusCount(){
		this.count--;
	}
	
	// Get and return a Seat
	public PassengerSeat getSeat(int row, int col) {
		return this.Seats[row - 1][col - 1];
	}
	
	// Populates the Seats array with Seats
	public void populatePlane(){
		for (int outCount = 0; outCount < ROWS; outCount++){
			for (int inCount = 0; inCount < COLS; inCount++){
				PassengerSeat tempSeat = new PassengerSeat();
				this.Seats[outCount][inCount] = tempSeat;
			}
		}
		
	}
	
	// Overwrites a Seat in Seats[][] with a new Seat
	public void addSeat(int row, int col){
		PassengerSeat newSeat = new PassengerSeat();
		newSeat.occupySeat();
		Seats[row - 1][col - 1] = newSeat;
	}
	
	// Un-occupies, or frees, a Seat from Seats[][]
	public void freeSeat(int row, int col){
		PassengerSeat replaceSeat = new PassengerSeat();
		replaceSeat.freeSeat();
		Seats[row - 1][col - 1] = replaceSeat;
	}
	
	// The displaySeats() method steps through the Seats[][] array
	public String displaySeats(){
		String identifier = "";
		for (int outCount = 0; outCount < ROWS; outCount++){
			identifier = identifier.concat((outCount + 1) + "\t\t");
			for (int inCount = 0; inCount < COLS; inCount++){
				switch (inCount) {
				case 0: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("A"));
						break;
				case 1: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("B"));
						break;
				case 2: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("C"));
						break;
				case 3: identifier = identifier.concat(Seats[outCount][inCount].returnSeatLetter("D"));
						break;
				}
				identifier = identifier.concat("\t\t");
			}
			identifier = identifier.concat("\n");
		}
		identifier = identifier.concat("\n");
		return identifier;
	}
	
	
	// This method checks that the user input is valid and possible
	public boolean isValidInput(String inputString, String operation){
		// Makes the flag and splits input into number and letter
		boolean flag = true;
		String[] splitInput = new String[2];
		int userRow, userCol = 0;
		String userLetterString = "";
		splitInput = inputString.split("");
		
			// Check if all seats have been booked
			if (operation.equals("book") && this.count >= (this.ROWS * this.COLS)) {
				outputField.append("You have booked all available seats!\n");
				flag = false;
				return flag;
			}
			
			// Try-catch statement to catch any possible exceptions. Input validation is handled here.
			try {
				userRow = Integer.parseInt(splitInput[0]);
				userLetterString = splitInput[1];
				if (userRow < 1 || userRow > 7){
					outputField.append("Please enter a valid row number.\n");
					flag = false;
					return flag;
				}
				// Converts column letter to number
				switch (userLetterString) {
				case "A": userCol = 1;
						break;
				case "B": userCol = 2;
						break;
				case "C": userCol = 3;
						break;
				case "D": userCol = 4;
						break;
				}
				
				// Do this if the user wants to book. Check if seat has been filled already
				if (operation.equals("book")){
					if (getSeat(userRow, userCol).getisVacant()) {
						addSeat(userRow, userCol);
						displaySeats();
						plusCount();	
					}
					else {
						outputField.append("That seat has already been filled! Please choose another seat.\n");
						flag = false;
					}
				// Do this if the user wants to unbook. Check if seat is already empty
				} else if (operation.equals("unbook")) {
					if (!getSeat(userRow, userCol).getisVacant()) {
						freeSeat(userRow, userCol);
						displaySeats();
						minusCount();	
					}
					else {
						outputField.append("That seat has not yet been booked!\n");
						flag = false;
					}
				}
				
			} catch (Exception e) {
				flag = false;
				outputField.append("Invalid input!\n");
			}
		
		return flag;
	}
	
	// This method handles the events from the buttons of the GUI.
	@Override
	public void actionPerformed(ActionEvent event) {
		String callingBtn = event.getActionCommand();
		
		// If the user pressed "Book Seat"
		if (callingBtn.equals("Book Seat")) {
			// Get input
			String input = rowInput.getSelectedItem().toString() + colInput.getSelectedItem().toString();
			// Check if input is valid by invoking validation method
			if (isValidInput(input, "book") == true) {
				outputField.append("Seat booked successfully!\n");
				displayPane.setText(displaySeats());
			}
		// If the user pressed "Unbook Seat"
		} else if (callingBtn.equals("Unbook Seat")) {
			// Get input
			String input = rowInput.getSelectedItem().toString() + colInput.getSelectedItem().toString();
			// Check if input is valid by invoking validation method
			if (isValidInput(input, "unbook") == true) {
				outputField.append("Seat unbooked successfully!\nGET OFF THE PLANE!\n");
				displayPane.setText(displaySeats());
			}
		// If the user pressed "Exit"
		} else if (callingBtn.equals("Exit")) {
			System.exit(0);
		}
		
		
	}
	
	public static void main(String[] args) {
		// Create GUI instance and set to visible.
		PassengerPlaneGUI plane = new PassengerPlaneGUI("Reservation System");
		plane.setVisible(true);
	}
}
